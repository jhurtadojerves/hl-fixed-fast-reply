// ==UserScript==
// @name         Respuesta rápida flotante
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  try to take over the world!
// @author       You
// @match        http://*.harrylatino.org/*
// @grant        none
// ==/UserScript==

(function() {
    "use strict";

    var fRStyle = document.createElement("style");
    fRStyle.textContent =
        "\n  .frFixed {\n    z-index: 1000;\n    bottom: 1%;\n    left: 0%;\n  }\n\n\n  #fRButton {\n    position: absolute;\n    top: 4%;\n    left: 87%;\n    font-weight: bold;\n    font-size: 20px;    \n  }\n  \n  #fRSize {\n    position: absolute;\n    bottom: 4%;\n    left: 2%;\n    font-weight: bold;\n    font-size: 20px;\n    width: 75px; \n  }\n\n";

    document.head.append(fRStyle);

    var fastReply = document.getElementById("fast_reply_wrapper");
    fastReply.style.position = "relative";
    var originalSize = fastReply.offsetWidth;
    console.log(fastReply.offsetWidth);

    var fRButton = document.createElement("button");

    fRButton.setAttribute("id", "fRButton");

    var cross = document.createTextNode("X");
    var plus = document.createTextNode("+");
    fRButton.appendChild(plus);
    var fRFixedStatus = false;

    fastReply.append(fRButton);

    var fRSize = document.createElement("input");
    fRSize.setAttribute("type", "number");
    fRSize.setAttribute("value", "" + parseInt(fastReply.offsetWidth));

    fRSize.setAttribute("id", "fRSize");

    fastReply.append(fRSize);

    fRButton.addEventListener("click", function() {
        if (!fRFixedStatus) {
            fastReply.classList.add("frFixed");
            fastReply.style.position = "fixed";
            fRSize.value = parseInt(fastReply.offsetWidth);
        } else {
            fastReply.classList.remove("frFixed");
            fastReply.style.position = "relative";
            fastReply.style.maxWidth = originalSize + "px";
            console.log(originalSize);
            fRSize.value = originalSize;
        }
        fRFixedStatus = !fRFixedStatus;
    });

    fRSize.addEventListener("change", function() {
        fastReply.style.maxWidth = fRSize.value + "px";
    });


})();